package com.img;

/**
 * @author : IMG
 * @create : 2024/10/21
 */
public interface MinecraftClientMixinInterface {
    public boolean getCurrentIsInGame();

    public void setCurrentIsInGame(boolean isInGame);

    public boolean getIsLoaded();

    public int getStartTick();
}
