package com.img.gui;

import com.img.DrawContextMixinInterface;
import com.img.function.AnimationFunction;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

/**
 * @author : IMG
 * @create : 2024/10/19
 */
public class Layer {
    private Identifier texture;

    private float x;
    private float y;
    private float width;
    private float height;
    private float scale;
    private float screenScale;

    private int u;
    private int v;
    private int regionWidth;
    private int regionHeight;
    private int textureWidth;
    private int textureHeight;

    private float alpha;

    public Layer() {
    }

    public Layer(Identifier texture, float x, float y, float width, float height, float scale, float screenScale, int u, int v, int regionWidth, int regionHeight, int textureWidth, int textureHeight, float aplha) {
        this.texture = texture;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.scale = scale;
        this.screenScale = screenScale;
        this.u = u;
        this.v = v;
        this.regionWidth = regionWidth;
        this.regionHeight = regionHeight;
        this.textureWidth = textureWidth;
        this.textureHeight = textureHeight;
        this.alpha = aplha;
    }

    public void render(int dX, int dY, DrawContext context, int mouseX, int mouseY, float delta, int currentWidth, int currentHeight, VirtualScreen virtualScreen) {
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, alpha);
        DrawContextMixinInterface drawContext = (DrawContextMixinInterface) context;
        drawContext.drawTexture(
                texture,
                dX + virtualScreen.toPracticalX(x),
                dY + virtualScreen.toPracticalY(y),
                virtualScreen.toPracticalX(width * scale),
                virtualScreen.toPracticalY(height * scale),
                u, v,
                regionWidth, regionHeight,
                textureWidth, textureHeight
        );
    }

    public Identifier getTexture() {
        return texture;
    }

    public void setTexture(Identifier texture) {
        this.texture = texture;
    }

    public float getX() {
        return x;
    }

    public void setX(float x) {
        this.x = x;
    }

    public float getY() {
        return y;
    }

    public void setY(float y) {
        this.y = y;
    }

    public float getWidth() {
        return width;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public float getScale() {
        return scale;
    }

    public void setScale(float scale) {
        this.scale = scale;
    }

    public float getScreenScale() {
        return screenScale;
    }

    public void setScreenScale(float screenScale) {
        this.screenScale = screenScale;
    }

    public int getU() {
        return u;
    }

    public void setU(int u) {
        this.u = u;
    }

    public int getV() {
        return v;
    }

    public void setV(int v) {
        this.v = v;
    }

    public int getRegionWidth() {
        return regionWidth;
    }

    public void setRegionWidth(int regionWidth) {
        this.regionWidth = regionWidth;
    }

    public int getRegionHeight() {
        return regionHeight;
    }

    public void setRegionHeight(int regionHeight) {
        this.regionHeight = regionHeight;
    }

    public int getTextureWidth() {
        return textureWidth;
    }

    public void setTextureWidth(int textureWidth) {
        this.textureWidth = textureWidth;
    }

    public int getTextureHeight() {
        return textureHeight;
    }

    public void setTextureHeight(int textureHeight) {
        this.textureHeight = textureHeight;
    }

    public float getAlpha() {
        return alpha;
    }

    public void setAlpha(float alpha) {
        this.alpha = alpha;
    }

    private Long duration;
    private Long startTime = null;
    private Long delay;
    private AnimationFunction<Float> xFunction;
    private AnimationFunction<Float> yFunction;
    private AnimationFunction<Float> alphaFunction;
    private AnimationFunction<Float> scaleFunction;

    public void tick() {

        if (delay == null || duration == 0){
            return;
        }

        long currentTime = System.currentTimeMillis();
        if (startTime == null) {
            startTime = currentTime;
        }else {
            long t = currentTime - startTime;
            if (t > delay){
                float time = Math.min((float) (t - delay) / duration, 1);
                if (xFunction != null){
                    x = xFunction.apply(time, x);
                }
                if (yFunction != null){
                    y = yFunction.apply(time, y);
                }
                if (alphaFunction != null){
                    alpha = alphaFunction.apply(time, alpha);
                }
                if (scaleFunction != null) {
                    scale = scaleFunction.apply(time, scale);
                }
            }
        }
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public Long getDuration() {
        return duration;
    }

    public void setDuration(Long duration) {
        this.duration = duration;
    }

    public Long getStartTime() {
        return startTime;
    }

    public void setStartTime(Long startTime) {
        this.startTime = startTime;
    }

    public Long getDelay() {
        return delay;
    }

    public void setDelay(Long delay) {
        this.delay = delay;
    }

    public void setXFunction(AnimationFunction<Float> xFunction) {
        this.xFunction = xFunction;
    }

    public void setYFunction(AnimationFunction<Float> yFunction) {
        this.yFunction = yFunction;
    }

    public void setAlphaFunction(AnimationFunction<Float> alphaFunction) {
        this.alphaFunction = alphaFunction;
    }

    public void setScaleFunction(AnimationFunction<Float> scaleFunction) {
        this.scaleFunction = scaleFunction;
    }

    public AnimationFunction<Float> getScaleFunction() {
        return scaleFunction;
    }
}
