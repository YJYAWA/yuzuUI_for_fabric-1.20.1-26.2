package com.img.mixin.client;

import com.img.MinecraftClientMixinInterface;
import com.img.init.InitSounds;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.RunArgs;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerWarningScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.CreateWorldScreen;
import net.minecraft.client.realms.gui.screen.RealmsGenericErrorScreen;
import net.minecraft.client.realms.gui.screen.RealmsMainScreen;
import net.minecraft.client.sound.MusicType;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.MusicSound;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * @author : IMG
 * @create : 2024/10/19
 */
@Mixin(MinecraftClient.class)
public class MinecraftClientMixin implements MinecraftClientMixinInterface {

    @Shadow public Screen currentScreen;
    private MusicSound musicSound = new MusicSound(RegistryEntry.of(InitSounds.YUZU_TITLE_MUSIC), 0, 0, true);

    @Unique
    private boolean currentIsInGame = true;

    @Unique
    private boolean isLoaded = false;

    @Unique
    private int startTick = 0;
//
//    @Inject(method = "getMusicType" , at = @At(value = "INVOKE", target = ""))
//    private void init(CallbackInfoReturnable<MusicSound> cir){
//        MusicType.MENU = musicSound;
//    }

    @Inject(method = "setScreen", at = @At("HEAD"))
    private void setScreen(Screen screen, CallbackInfo ci) {
        Screen currentScreen = this.currentScreen;
        if (screen == null && !(currentScreen instanceof CreateWorldScreen || currentScreen instanceof MultiplayerScreen || currentScreen instanceof MultiplayerWarningScreen || currentScreen instanceof RealmsMainScreen || currentScreen instanceof OptionsScreen || currentScreen instanceof RealmsGenericErrorScreen)) {
            if (!currentIsInGame) {
                this.currentIsInGame = true;
            }
        }
    }

    @Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/sound/MusicTracker;tick()V"))
    public void tick(CallbackInfo ci) {
        if (!isLoaded) {
            isLoaded = true;
        }
        if (startTick <= 50) {
            startTick++;
        }
    }


    @Override
    public boolean getCurrentIsInGame() {
        return this.currentIsInGame;
    }

    @Override
    public void setCurrentIsInGame(boolean currentIsInGame) {
        this.currentIsInGame = currentIsInGame;
    }

    @Override
    public boolean getIsLoaded() {
        return this.isLoaded;
    }

    @Override
    public int getStartTick() {
        return this.startTick;
    }
}
