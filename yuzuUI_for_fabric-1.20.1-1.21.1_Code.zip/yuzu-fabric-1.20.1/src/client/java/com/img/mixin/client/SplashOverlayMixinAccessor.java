package com.img.mixin.client;

import net.minecraft.client.gui.screen.SplashOverlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * @author : IMG
 * @create : 2024/10/22
 */
@Mixin(SplashOverlay.class)
public interface SplashOverlayMixinAccessor {

    @Accessor("reloadCompleteTime")
    public long getReloadCompleteTime();
}
