package com.img.mixin.client;

import com.img.DrawContextMixinInterface;
import com.img.MinecraftClientMixinInterface;
import com.img.YuZuUI;
import com.img.gui.Layer;
import com.img.gui.TitleButtonWidget;
import com.img.gui.VirtualScreen;
import com.img.init.InitSounds;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Overlay;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.SplashOverlay;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerWarningScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.CreateWorldScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.realms.gui.screen.RealmsMainScreen;
import net.minecraft.client.realms.gui.screen.RealmsNotificationsScreen;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.concurrent.CompletableFuture;

import static java.lang.Thread.sleep;

@Mixin(TitleScreen.class)
public abstract class TitleClientMixin extends Screen {

	@Shadow private RealmsNotificationsScreen realmsNotificationGui;

	@Shadow protected abstract boolean isRealmsNotificationsGuiDisplayed();

	@Shadow @Final private boolean doBackgroundFade;
	private static final Identifier BACKGROUND_TEXTURE = Identifier.of(YuZuUI.MOD_ID, "textures/gui/background.png");
	private static final Identifier TITLE_YOSHINO  = Identifier.of(YuZuUI.MOD_ID, "textures/gui/title_yoshino.png");
	private static final Identifier TITLE_MURASAME = Identifier.of(YuZuUI.MOD_ID, "textures/gui/title_murasame.png");
	private static final Identifier TITLE_MAKO = Identifier.of(YuZuUI.MOD_ID, "textures/gui/title_mako.png");
	private static final Identifier TITLE_LENA = Identifier.of(YuZuUI.MOD_ID, "textures/gui/title_lena.png");
	private static final Identifier TITLE_LOGO = Identifier.of(YuZuUI.MOD_ID, "textures/gui/title_logo.png");
	private static final Identifier TITLE_HEAD = Identifier.of(YuZuUI.MOD_ID, "textures/gui/title_head.png");

	private static final Identifier TITLE_NEW_GAME_BUTTON_NORMAL = Identifier.of(YuZuUI.MOD_ID, "textures/gui/title_new_game_button_normal.png");
	private static final Identifier TITLE_NEW_GAME_BUTTON_ON = Identifier.of(YuZuUI.MOD_ID, "textures/gui/title_new_game_button_on.png");

	private static final Identifier TITLE_SELECT_WORLD_BUTTON_NORMAL = Identifier.of(YuZuUI.MOD_ID, "textures/gui/title_select_world_button_normal.png");
	private static final Identifier TITLE_SELECT_WORLD_BUTTON_ON = Identifier.of(YuZuUI.MOD_ID, "textures/gui/title_select_world_button_on.png");

	private static final Identifier TITLE_OPTIONS_BUTTON_NORMAL = Identifier.of(YuZuUI.MOD_ID, "textures/gui/title_options_button_normal.png");
	private static final Identifier TITLE_OPTIONS_BUTTON_ON = Identifier.of(YuZuUI.MOD_ID, "textures/gui/title_options_button_on.png");

	private static final Identifier TITLE_QUIT_GAME_BUTTON_NORMAL = Identifier.of(YuZuUI.MOD_ID, "textures/gui/title_quit_game_button_normal.png");
	private static final Identifier TITLE_QUIT_GAME_BUTTON_ON = Identifier.of(YuZuUI.MOD_ID, "textures/gui/title_quit_game_button_on.png");

	private static final Identifier TITLE_CONTINUE_BUTTON_NORMAL = Identifier.of(YuZuUI.MOD_ID, "textures/gui/title_continue_button_normal.png");
	private static final Identifier TITLE_CONTINUE_BUTTON_ON = Identifier.of(YuZuUI.MOD_ID, "textures/gui/title_continue_button_on.png");

	private static final Identifier TITLE_REAMLS_BUTTON_NORMAL = Identifier.of(YuZuUI.MOD_ID, "textures/gui/title_realms_button_normal.png");
	private static final Identifier TITLE_REAMLS_BUTTON_ON = Identifier.of(YuZuUI.MOD_ID, "textures/gui/title_realms_button_on.png");



	private static final double a = 0.06;

	private static Layer yoshinoLayer;
	private static Layer murasameLayer;
	private static Layer makoLayer;
	private static Layer lenaLayer;

	private static Layer logoLayer;

	private static Layer headLayer;

	private static final VirtualScreen virtualScreen = new VirtualScreen(1920, 1080);

	private static int y = 346;
	private static int dy = 120;
	private static Long delay = 1300L;

	private static TitleButtonWidget newGameButton;

	private static TitleButtonWidget selectWorldButton;

	private static TitleButtonWidget continueButton;

	private static TitleButtonWidget realmsButton;

	private static TitleButtonWidget optionsButton;

	private static TitleButtonWidget quitGameButton;

	protected TitleClientMixin(Text title) {
		super(title);
	}

	@Inject(method = "render", at = @At(value = "HEAD"), cancellable = true)
	private void render(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
		// 背景图片保持比例
		int screenWidth = this.width;
		int screenHeight = this.height;
		// 背景适应后的数据
		int currentWidth;
		int currentHeight;
		if (screenWidth * 9 > screenHeight * 16) {
			currentWidth = screenHeight * 16 / 9;
			currentHeight = screenHeight;
		}else {
			currentWidth = screenWidth;
			currentHeight = screenWidth * 9 / 16;
		}
		int currentX = (screenWidth - currentWidth) / 2;
		int currentY = (screenHeight - currentHeight) / 2;

		virtualScreen.setPracticalWidth(currentWidth);
		virtualScreen.setPracticalHeight(currentHeight);
		virtualScreen.setX(currentX);
		virtualScreen.setY(currentY);

		context.fill(0, 0, screenWidth, screenHeight, 0xFF000000);
		context.enableScissor(currentX, currentY, currentX + currentWidth, currentY + currentHeight);

		RenderSystem.enableBlend();
		RenderSystem.setShader(GameRenderer::getPositionTexProgram);


		context.drawTexture(BACKGROUND_TEXTURE, currentX, currentY, currentWidth, currentHeight, 0.0F, 0.0F, 16, 16, 16, 16);


		lenaLayer.render(currentX, currentY, context, mouseX, mouseY, delta, currentWidth, currentHeight, virtualScreen);
		makoLayer.render(currentX, currentY, context, mouseX, mouseY, delta, currentWidth, currentHeight, virtualScreen);
		murasameLayer.render(currentX, currentY, context, mouseX, mouseY, delta, currentWidth, currentHeight, virtualScreen);
		yoshinoLayer.render(currentX, currentY, context, mouseX, mouseY, delta, currentWidth, currentHeight, virtualScreen);

		RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
		context.setShaderColor(1.0F, 1.0F, 1.0F, headLayer.getAlpha());
		context.fill(currentX, currentY, currentX + (int) virtualScreen.toPracticalX(296), currentY + (int) virtualScreen.toPracticalY(1080), 0xFFFFFFFF);
		DrawContextMixinInterface drawContext = (DrawContextMixinInterface) context;
		drawContext.fillGradientVertical(currentX + (int) virtualScreen.toPracticalX(296), currentY, currentX + (int) virtualScreen.toPracticalX(600), currentY + (int) virtualScreen.toPracticalY(1080), 0, 0xFFFFFFFF, 0x00FFFFFF);
		RenderSystem.enableBlend();
		context.setShaderColor(1.0F, 1.0F, 1.0F, headLayer.getAlpha());
		context.drawTexture(TITLE_HEAD, currentX,  currentY + (int) virtualScreen.toPracticalY(334),  (int) virtualScreen.toPracticalX(12), (int) virtualScreen.toPracticalY(687), 0f, 0f, 256, 256, 256, 256);

		newGameButton.render(context, mouseX, mouseY, delta);
		selectWorldButton.render(context, mouseX, mouseY, delta);
		continueButton.render(context, mouseX, mouseY, delta);
		realmsButton.render(context, mouseX, mouseY, delta);
		optionsButton.render(context, mouseX, mouseY, delta);
		quitGameButton.render(context, mouseX, mouseY, delta);

		logoLayer.render(currentX, currentY, context, mouseX, mouseY, delta, currentWidth, currentHeight, virtualScreen);

		context.disableScissor();
		RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
		// 直接覆盖
		ci.cancel();
	}

	@Inject(method = "tick", at = @At("TAIL"))
	public void tick(CallbackInfo ci) {
		MinecraftClientMixinInterface client = (MinecraftClientMixinInterface) this.client;
//		if(client.getIsLoaded() && client.getStartTick() >= 50) {
		Overlay overlay = this.client.getOverlay();
		if(overlay == null || (overlay instanceof SplashOverlay && ((SplashOverlayMixinAccessor)overlay).getReloadCompleteTime() != -1L)){
			yoshinoLayer.tick();
			murasameLayer.tick();
			makoLayer.tick();
			lenaLayer.tick();
			headLayer.tick();
			logoLayer.tick();
			newGameButton.tick();
			selectWorldButton.tick();
			continueButton.tick();
			realmsButton.tick();
			optionsButton.tick();
			quitGameButton.tick();
		}
	}

	private void initWidgets(){
		if (!this.doBackgroundFade) {
			delay = 200L;
		}

		yoshinoLayer = new Layer(TITLE_YOSHINO, 504, 50, 973, 1058, 1f, 1f, 0, 0, 256, 256, 256, 256, 0f){{
			setDelay(delay);
			setDuration(590L);

			setYFunction((t, now) -> {
//			return (25f - now) * t + now;
				return (25f - 50f) * (float) ((Math.pow(a, t) - 1) / (a - 1))  + 50f;
			});

			setAlphaFunction((t, now) -> {
//			return (1f - now) * t + now;
				return (1f - 0f) * (float) ((Math.pow(a, t) - 1) / (a - 1)) + 0f;
			});
		}};

		murasameLayer = new Layer(TITLE_MURASAME, 221, 90, 1045, 994, 1f, 1f, 0, 0, 256, 256, 256, 256, 0f){{
			setDelay(delay + 110L);
			setDuration(710L);

			setXFunction((t, now) -> {
//			return (173f - now) * t + now;
				return (173f - 221f) * (float) ((Math.pow(a, t) - 1) / (a - 1)) + 221f;
			});

			setAlphaFunction((t, now) -> {
//			return (1f - now) * t + now;
				return (1f - 0f) * (float) ((Math.pow(a, t) - 1) / (a - 1)) + 0f;
			});
		}};

		makoLayer = new Layer(TITLE_MAKO, 805, 387, 1118, 694, 1f, 1f,0, 0, 256, 256, 256, 256, 0f){{
			setDelay(delay + 280L);
//		setDelay(3100L);
			setDuration(680L);

			setXFunction((t, now) -> {
//			return (898f - now) * t + now;
				return (898f - 805f) * (float) ((Math.pow(a, t) - 1) / (a - 1)) + 805f;
			});

			setAlphaFunction((t, now) -> {
//			return (1f - now) * t + now;
				return (1f - 0f) * (float) ((Math.pow(a, t) - 1) / (a - 1)) + 0f;
			});
		}};

		lenaLayer = new Layer(TITLE_LENA, 1002, 149,876, 1053, 1f, 1f, 0, 0, 256, 256, 256, 256, 0f){{
			setDelay(delay + 440L);
			setDuration(680L);

			setXFunction((t, now) -> {
//			return (1065f - now) * t + now;
				return (float)((1065f - 1002f) *  ((Math.pow(0.05, t) - 1) / (0.05 - 1)) + 1002f);
			});

			setYFunction((t, now) -> {
//			return (27f - now) * t + now;
				return (float)((27f - 149f) * ((Math.pow(0.05, t) - 1) / (0.05 - 1)) + 149f);
			});

			setAlphaFunction((t, now) -> {
//			return (1f - now) * t + now;
				return (float)((1f - 0f) * ((Math.pow(0.05, t) - 1) / (0.05 - 1)) + 0f);
			});
		}};

		logoLayer = new Layer(TITLE_LOGO, 17, 57, 442, 188, 1.067f, 1f, 0, 0, 256, 256, 256, 256, 0f){{
			setDelay(delay + 300L);
			setDuration(570L);

			setXFunction((t, now) -> {
//			return (31f - 17f) * t + 17f;
				return (31f - 17f) * (float) ((Math.pow(0.1, t) - 1) / (0.1 - 1)) + 17f;
			});

			setYFunction((t, now) -> {
//			return (60f - 57f) * t + 57f;
				return (60f - 57f) * (float) ((Math.pow(0.1, t) - 1) / (0.1 - 1)) + 57f;
			});

			setAlphaFunction((t, now) -> {
//			return (1f - 0f) * t + 0f;
				return (1f - 0f) * (float) ((Math.pow(0.1, t) - 1) / (0.1 - 1)) + 0f;
			});

			setScaleFunction((t, now) -> {
//			return (1f - 1.067f) * t + 1.067f;
				return (1f - 1.067f) * (float) ((Math.pow(0.1, t) - 1) / (0.1 - 1)) + 1.067f;
			});
		}};

		headLayer = new Layer(TITLE_HEAD, 0, 0, 536, 1080, 1f, 1f, 0, 0, 256, 256, 256, 256, 0f){{
			setDelay(delay + 1130L);
			setDuration(530L);

			setAlphaFunction((t, now) -> {
				float v = (1f - 0f) * (float) ((Math.pow(0.1, t) - 1) / (0.1 - 1)) + 0f;
				if (v == 1f && now != 1f){
					MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(InitSounds.YUZU_TITLE_SENREN, 1.0f, 10.0f));
				}
				return v;
			});
		}};

		newGameButton = new TitleButtonWidget(60, y, 207, 54, Text.of("new game"), TITLE_NEW_GAME_BUTTON_NORMAL, TITLE_NEW_GAME_BUTTON_ON, virtualScreen, 0f){{
			setDelay(delay + 1670L);
			setDuration(570L);

			setAlphaFunction((t, now) -> {
				return (1f - 0f) * t + 0f;
			});
		}};

		selectWorldButton = new TitleButtonWidget(60, y + dy, 206, 55, Text.of("select world"), TITLE_SELECT_WORLD_BUTTON_NORMAL, TITLE_SELECT_WORLD_BUTTON_ON, virtualScreen, 0f){{
			setDelay(delay + 1670L);
			setDuration(570L);

			setAlphaFunction((t, now) -> {
				return (1f - 0f) * t + 0f;
			});
		}};

		continueButton = new TitleButtonWidget(66, y + dy * 2, 313, 56, Text.of("continue"), TITLE_CONTINUE_BUTTON_NORMAL, TITLE_CONTINUE_BUTTON_ON, virtualScreen, 0f){{
			setDelay(delay + 1670L);
			setDuration(570L);

			setAlphaFunction((t, now) -> {
				return (1f - 0f) * t + 0f;
			});
		}};

		realmsButton = new TitleButtonWidget(66, y + dy * 3, 164, 54, Text.of("realms"), TITLE_REAMLS_BUTTON_NORMAL, TITLE_REAMLS_BUTTON_ON, virtualScreen, 0f){{
			setDelay(delay + 1670L);
			setDuration(570L);

			setAlphaFunction((t, now) -> {
				return (1f - 0f) * t + 0f;
			});
		}};

		optionsButton = new TitleButtonWidget(59, y + dy * 4, 253, 56, Text.of("options"), TITLE_OPTIONS_BUTTON_NORMAL, TITLE_OPTIONS_BUTTON_ON, virtualScreen, 0f){{
			setDelay(delay + 1670L);
			setDuration(570L);

			setAlphaFunction((t, now) -> {
				return (1f - 0f) * t + 0f;
			});
		}};

		quitGameButton = new TitleButtonWidget(60, y + dy * 5, 233, 54, Text.of("quit game"), TITLE_QUIT_GAME_BUTTON_NORMAL, TITLE_QUIT_GAME_BUTTON_ON, virtualScreen, 0f){{
			setDelay(delay + 1670L);
			setDuration(570L);

			setAlphaFunction((t, now) -> {
				return (1f - 0f) * t + 0f;
			});
		}};
	}

	@Inject(method = "initWidgetsNormal", at = @At("HEAD"), cancellable = true)
	public void initWidgetsNormal(int y, int spacingY, CallbackInfo ci){
		MinecraftClientMixinInterface client = (MinecraftClientMixinInterface) this.client;
		if (client.getCurrentIsInGame()) {
			initWidgets();
			client.setCurrentIsInGame(false);
		}

		newGameButton.setOnClick((button) -> {
//			MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(InitSounds.YUZU_TITLE_BUTTON_NEW_GAME, 1.0f, 10.0f));
			CreateWorldScreen.create(this.client, this);
		});

		selectWorldButton.setOnClick((button) -> {
			MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(InitSounds.YUZU_TITLE_BUTTON_SELECT_WORLD, 1.0f, 10.0f));
			this.client.setScreen(new SelectWorldScreen(this));
		});

		continueButton.setOnClick((button) -> {
			Screen screen = this.client.options.skipMultiplayerWarning ? new MultiplayerScreen(this) : new MultiplayerWarningScreen(this);
			this.client.setScreen((Screen)screen);
		});

		realmsButton.setOnClick((button) -> {
			MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(InitSounds.YUZU_TITLE_BUTTON_REALMS, 1.0f, 10.0f));
			this.client.setScreen(new RealmsMainScreen(this));
		});

		optionsButton.setOnClick((button) -> {
			MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(InitSounds.YUZU_TITLE_BUTTON_OPTIONS, 1.0f, 10.0f));
			this.client.setScreen(new OptionsScreen(this, this.client.options));
		});

		quitGameButton.setOnClick((button) -> {
			MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(InitSounds.YUZU_TITLE_BUTTON_QUIT_GAME, 1.0f, 10.0f));
			CompletableFuture.completedFuture(null).whenComplete((unused, e) -> {
                try {
                    sleep(1500);
                } catch (InterruptedException ex) {
                    throw new RuntimeException(ex);
                }
                this.client.scheduleStop();
			});
		});

		this.addDrawableChild(newGameButton);
		this.addDrawableChild(selectWorldButton);
		this.addDrawableChild(continueButton);
		this.addDrawableChild(realmsButton);
		this.addDrawableChild(optionsButton);
		this.addDrawableChild(quitGameButton);
		// 跳过
		ci.cancel();
	}

	@Inject(method = "init", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screen/TitleScreen;addDrawableChild(Lnet/minecraft/client/gui/Element;)Lnet/minecraft/client/gui/Element;"), cancellable = true)
	public void init(CallbackInfo ci) {
		this.client.setConnectedToRealms(false);
		if (this.realmsNotificationGui == null) {
			this.realmsNotificationGui = new RealmsNotificationsScreen();
		}

		if (this.isRealmsNotificationsGuiDisplayed()) {
			this.realmsNotificationGui.init(this.client, this.width, this.height);
		}
		ci.cancel();
	}

	@Inject(method = "onDisplayed", at = @At("TAIL"))
	public void onDisplayed(CallbackInfo ci) {
	}

}