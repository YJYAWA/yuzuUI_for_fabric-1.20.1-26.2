package com.img.gui;

import com.img.DrawContextMixinInterface;
import com.img.function.AnimationFunction;
import com.img.init.InitSounds;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.*;
import net.minecraft.client.gui.navigation.GuiNavigation;
import net.minecraft.client.gui.navigation.GuiNavigationPath;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.Widget;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;
import java.util.function.Function;

/**
 * @author : IMG
 * @create : 2024/10/20
 */
public class TitleButtonWidget implements Drawable, Element, Widget, Selectable {
    private int x;
    private int y;
    private int width;
    private int height;
    private float alpha;

    public boolean visible = true;
    private boolean isHovered = false;
    private boolean isFocused = false;

    private Identifier texture;
    private Identifier textureHover;
    private VirtualScreen virtualScreen;

    private Consumer<TitleButtonWidget> onClick;

    public TitleButtonWidget(int x, int y, int width, int height, Text message, Identifier texture, Identifier textureHover, VirtualScreen virtualScreen, float alpha) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.texture = texture;
        this.textureHover = textureHover;
        this.virtualScreen = virtualScreen;
        this.alpha = alpha;
    }

    public void renderButton(DrawContext context, int mouseX, int mouseY, float delta) {
        DrawContextMixinInterface drawContext = (DrawContextMixinInterface) context;
        if (this.visible) {
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, this.alpha);
            if (this.isHovered()) {
                drawContext.drawTexture(
                        textureHover,
                        virtualScreen.getX() + virtualScreen.toPracticalX(getX()),
                        virtualScreen.getY() + virtualScreen.toPracticalY(getY()),
                        virtualScreen.toPracticalX(width),
                        virtualScreen.toPracticalY(height),
                        0, 0,
                        256, 256,
                        256, 256
                );
            } else {
                drawContext.drawTexture(
                        texture,
                        virtualScreen.getX() + virtualScreen.toPracticalX(getX()),
                        virtualScreen.getY() + virtualScreen.toPracticalY(getY()),
                        virtualScreen.toPracticalX(width),
                        virtualScreen.toPracticalY(height),
                        0, 0,
                        256, 256,
                        256, 256
                );
            }
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        if (this.visible) {
            if (!isHovered() && isMouseOver(mouseX, mouseY)) {
                MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(InitSounds.YUZU_TITLE_BUTTON_ON, 1.0f, 1.0f));
            }
            this.isHovered = this.isMouseOver(mouseX, mouseY);
            this.renderButton(context, mouseX, mouseY, delta);
        }
    }

    @Override
    public void mouseMoved(double mouseX, double mouseY) {
        Element.super.mouseMoved(mouseX, mouseY);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (this.visible && this.isMouseOver(mouseX, mouseY)) {
            MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(InitSounds.YUZU_TITLE_BUTTON_CLICK, 1.0f, 1.0f));
            if (this.onClick != null) {
                this.onClick.accept(this);
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        return Element.super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        return Element.super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        return Element.super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        return Element.super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean keyReleased(int keyCode, int scanCode, int modifiers) {
        return Element.super.keyReleased(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        return Element.super.charTyped(chr, modifiers);
    }

    @Nullable
    @Override
    public GuiNavigationPath getNavigationPath(GuiNavigation navigation) {
        return Element.super.getNavigationPath(navigation);
    }

    @Override
    public void setFocused(boolean focused) {
        this.isFocused = focused;
    }

    @Override
    public boolean isFocused() {
        return this.isFocused;
    }

    @Nullable
    @Override
    public GuiNavigationPath getFocusedPath() {
        return Element.super.getFocusedPath();
    }

    @Override
    public ScreenRect getNavigationFocus() {
        return Element.super.getNavigationFocus();
    }

    @Override
    public void forEachChild(Consumer<ClickableWidget> consumer) {

    }

    @Override
    public void appendNarrations(NarrationMessageBuilder builder) {

    }

    @Override
    public void setX(int x) {
        this.x = x;
    }

    @Override
    public void setY(int y) {
        this.y = y;
    }

    @Override
    public int getX() {
        return this.x;
    }

    @Override
    public int getY() {
        return this.y;
    }

    @Override
    public int getWidth() {
        return this.width;
    }

    @Override
    public int getHeight() {
        return this.height;
    }

    @Override
    public boolean isMouseOver(double mouseX, double mouseY) {
        float virtualX = virtualScreen.toVirtualX((float) mouseX) - x;
        float virtualY = virtualScreen.toVirtualY((float) mouseY) - y;
        return virtualX >= 0 && virtualX < width && virtualY >= 0 && virtualY < height;
    }

    public boolean isHovered() {
        return this.isHovered;
    }

    public Selectable.SelectionType getType() {
        if (this.isFocused()) {
            return SelectionType.FOCUSED;
        } else {
            return this.isHovered ? SelectionType.HOVERED : SelectionType.NONE;
        }
    }

    public float getAlpha() {
        return alpha;
    }

    public void setAlpha(float alpha) {
        this.alpha = alpha;
    }

    public void setOnClick(Consumer<TitleButtonWidget> onClick) {
        this.onClick = onClick;
    }

    /**
     * 动画相关
     */
    private Long duration;
    private Long startTime = null;
    private Long delay;
    private AnimationFunction<Float> alphaFunction;

    public void setAlphaFunction(AnimationFunction<Float> alphaFunction) {
        this.alphaFunction = alphaFunction;
    }

    public void tick(){
        if (delay == null || duration == 0){
            return;
        }

        long currentTime = System.currentTimeMillis();
        if (startTime == null) {
            startTime = currentTime;
        }else {
            long t = currentTime - startTime;
            if (t > delay) {
                float time = Math.min((float) (t - delay) / duration, 1);
                if (alphaFunction != null) {
                    alpha = alphaFunction.apply(time, alpha);
                }
            }
        }
    }

    public void setDelay(Long delay) {
        this.delay = delay;
    }

    public void setDuration(Long duration) {
        this.duration = duration;
    }


}
