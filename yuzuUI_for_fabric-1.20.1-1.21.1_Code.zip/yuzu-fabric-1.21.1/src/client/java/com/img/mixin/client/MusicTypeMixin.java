package com.img.mixin.client;

import com.img.init.InitSounds;
import net.minecraft.sound.MusicType;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.MusicSound;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * @author : IMG
 * @create : 2024/10/19
 */
@Mixin(MusicType.class)
public class MusicTypeMixin {

    @Mutable
    @Shadow @Final public static MusicSound MENU;

    @Inject(method = "<clinit>" , at = @At(value = "TAIL"))
    private static void init(CallbackInfo ci) {
        MENU = new MusicSound(RegistryEntry.of(InitSounds.YUZU_TITLE_MUSIC), 50, 50, true);
    }
}
