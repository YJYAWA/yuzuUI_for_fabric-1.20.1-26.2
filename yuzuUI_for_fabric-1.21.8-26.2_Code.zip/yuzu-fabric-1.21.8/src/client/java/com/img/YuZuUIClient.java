package com.img;

import net.fabricmc.api.ClientModInitializer;

public class YuZuUIClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.

	}
}