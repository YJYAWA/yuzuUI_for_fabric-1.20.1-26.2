package com.img.gui;

import com.img.function.AnimationFunction;
import com.img.init.InitSounds;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;

/**
 * @author : IMG
 * @create : 2024/10/20
 *
 * 1.21.8：不再实现原版控件接口，改为一个自绘 + 自命中测试的普通按钮对象，
 * 由自绘的 {@link YuZuTitleScreen} 直接驱动。
 */
public class TitleButton {

    private int x;
    private int y;
    private int width;
    private int height;
    private float alpha;

    public boolean visible = true;
    private boolean isHovered = false;

    private final Identifier texture;
    private final Identifier textureHover;
    private final VirtualScreen virtualScreen;

    @Nullable
    private Consumer<TitleButton> onClick;

    public TitleButton(int x, int y, int width, int height, Identifier texture, Identifier textureHover, VirtualScreen virtualScreen, float alpha) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.texture = texture;
        this.textureHover = textureHover;
        this.virtualScreen = virtualScreen;
        this.alpha = alpha;
    }

    public static void playSound(SoundEvent sound, float pitch, float volume) {
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(sound, pitch, volume));
    }

    /**
     * 绘制并处理悬停音效。mouseX / mouseY 为 GUI 坐标。
     */
    public void render(DrawContext context, double mouseX, double mouseY) {
        if (!this.visible) {
            return;
        }
        boolean hovered = isMouseOver(mouseX, mouseY);
        if (hovered && !this.isHovered) {
            playSound(InitSounds.YUZU_TITLE_BUTTON_ON, 1.0F, 1.0F);
        }
        this.isHovered = hovered;

        context.drawTexture(
                RenderPipelines.GUI_TEXTURED,
                hovered ? textureHover : texture,
                virtualScreen.getX() + (int) virtualScreen.toPracticalX(x),
                virtualScreen.getY() + (int) virtualScreen.toPracticalY(y),
                0.0F,
                0.0F,
                (int) virtualScreen.toPracticalX(width),
                (int) virtualScreen.toPracticalY(height),
                256,
                256,
                256,
                256,
                Layer.toColor(this.alpha)
        );
    }

    public boolean mouseClicked(double mouseX, double mouseY) {
        if (this.visible && isMouseOver(mouseX, mouseY)) {
            playSound(InitSounds.YUZU_TITLE_BUTTON_CLICK, 1.0F, 1.0F);
            if (this.onClick != null) {
                this.onClick.accept(this);
            }
            return true;
        }
        return false;
    }

    public boolean isMouseOver(double mouseX, double mouseY) {
        float virtualX = virtualScreen.toVirtualX((float) mouseX) - x;
        float virtualY = virtualScreen.toVirtualY((float) mouseY) - y;
        return virtualX >= 0 && virtualX < width && virtualY >= 0 && virtualY < height;
    }

    public boolean isHovered() {
        return this.isHovered;
    }

    public float getAlpha() {
        return alpha;
    }

    public void setAlpha(float alpha) {
        this.alpha = alpha;
    }

    public void setOnClick(Consumer<TitleButton> onClick) {
        this.onClick = onClick;
    }

    /**
     * 动画相关
     */
    private Long duration;
    private Long startTime = null;
    private Long delay;
    private AnimationFunction<Float> alphaFunction;

    public void setAlphaFunction(AnimationFunction<Float> alphaFunction) {
        this.alphaFunction = alphaFunction;
    }

    public void tick() {
        if (delay == null || duration == null || duration == 0) {
            return;
        }

        long currentTime = System.currentTimeMillis();
        if (startTime == null) {
            startTime = currentTime;
        } else {
            long t = currentTime - startTime;
            if (t > delay) {
                float time = Math.min((float) (t - delay) / duration, 1);
                if (alphaFunction != null) {
                    alpha = alphaFunction.apply(time, alpha);
                }
            }
        }
    }

    public void setDelay(Long delay) {
        this.delay = delay;
    }

    public void setDuration(Long duration) {
        this.duration = duration;
    }
}
