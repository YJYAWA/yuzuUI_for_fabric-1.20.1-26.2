package com.img.gui;

/**
 * @author : IMG
 * @create : 2024/10/19
 */
public class VirtualScreen {
    // 虚拟宽高
    private int virtualWidth;
    private int virtualHeight;

    // 实际宽高
    private int practicalWidth;
    private int practicalHeight;

    private int dX;
    private int dY;

    public VirtualScreen() {
    }

    public VirtualScreen(int virtualWidth, int virtualHeight) {
        this.virtualWidth = virtualWidth;
        this.virtualHeight = virtualHeight;
    }

    public float toPracticalX(float x) {
        return x * (float) practicalWidth / (float) virtualWidth;
    }

    public float toPracticalY(float y) {
        return y * (float) practicalHeight / (float) virtualHeight;
    }

    public float toVirtualX(float x) {
        return (x - dX) * (float) virtualWidth / (float) practicalWidth;
    }

    public float toVirtualY(float y) {
        return (y - dY) * (float) virtualHeight / (float) practicalHeight;
    }

    public int getVirtualWidth() {
        return virtualWidth;
    }

    public void setVirtualWidth(int virtualWidth) {
        this.virtualWidth = virtualWidth;
    }

    public int getVirtualHeight() {
        return virtualHeight;
    }

    public void setVirtualHeight(int virtualHeight) {
        this.virtualHeight = virtualHeight;
    }

    public int getPracticalWidth() {
        return practicalWidth;
    }

    public void setPracticalWidth(int practicalWidth) {
        this.practicalWidth = practicalWidth;
    }

    public int getPracticalHeight() {
        return practicalHeight;
    }

    public void setPracticalHeight(int practicalHeight) {
        this.practicalHeight = practicalHeight;
    }

    public int getX() {
        return dX;
    }

    public void setX(int dX) {
        this.dX = dX;
    }

    public int getY() {
        return dY;
    }

    public void setY(int dY) {
        this.dY = dY;
    }
}
