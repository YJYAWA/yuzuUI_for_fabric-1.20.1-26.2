package com.img.mixin.client;

import com.img.gui.YuZuTitleScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * @author : IMG
 * @create : 2024/10/20
 *
 * 1.21.8：原版 TitleScreen 内部结构已改写，改为在 {@code MinecraftClient.setScreen}
 * 处把原版 TitleScreen 换成自绘的 {@link YuZuTitleScreen}。
 *
 * <p>注意：{@code setScreen} 内部对 {@code screen == null && world == null} 的情况
 * 会把局部变量赋值为 {@code new TitleScreen()}，这个赋值发生在方法体内，
 * {@code @ModifyVariable(argsOnly = true)} 无法拦截，因此必须在 HEAD 处 @Inject 并 cancel。
 */
@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {

    @Shadow
    private boolean disconnecting;

    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void yuzu$replaceTitleScreen(Screen screen, CallbackInfo ci) {
        MinecraftClient client = (MinecraftClient) (Object) this;

        // 递归调用是安全的：内层传入的是 YuZuTitleScreen，既不为 null 也不是 TitleScreen，
        // 会直接 return，不会再触发替换。
        if (screen != null) {
            if (screen.getClass() == TitleScreen.class) {
                client.setScreen(new YuZuTitleScreen());
                ci.cancel();
            }
            return;
        }

        // 与原版判断保持一致：disconnecting 时原版会抛 IllegalStateException，不要拦截。
        if (!this.disconnecting && client.world == null) {
            client.setScreen(new YuZuTitleScreen());
            ci.cancel();
        }
    }
}
