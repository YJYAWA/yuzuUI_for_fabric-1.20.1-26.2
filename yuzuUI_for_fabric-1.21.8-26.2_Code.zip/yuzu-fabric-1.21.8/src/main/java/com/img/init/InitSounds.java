package com.img.init;

import com.img.YuZuUI;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/**
 * @author : IMG
 * @create : 2024/10/19
 */
public class InitSounds {

    public static final SoundEvent YUZU_TITLE_MUSIC = SoundEvent.of(Identifier.of(YuZuUI.MOD_ID, "yuzu_title_music"));

    public static final SoundEvent YUZU_TITLE_BUTTON_ON = SoundEvent.of(Identifier.of(YuZuUI.MOD_ID, "yuzu_title_button_on"));

    public static final SoundEvent YUZU_TITLE_BUTTON_CLICK = SoundEvent.of(Identifier.of(YuZuUI.MOD_ID, "yuzu_title_button_click"));

    public static final SoundEvent YUZU_TITLE_BUTTON_NEW_GAME = SoundEvent.of(Identifier.of(YuZuUI.MOD_ID, "yuzu_title_button_new_game"));

    public static final SoundEvent YUZU_TITLE_BUTTON_SELECT_WORLD = SoundEvent.of(Identifier.of(YuZuUI.MOD_ID, "yuzu_title_button_select_world"));

    public static final SoundEvent YUZU_TITLE_BUTTON_OPTIONS = SoundEvent.of(Identifier.of(YuZuUI.MOD_ID, "yuzu_title_button_options"));

    public static final SoundEvent YUZU_TITLE_BUTTON_QUIT_GAME = SoundEvent.of(Identifier.of(YuZuUI.MOD_ID, "yuzu_title_button_quit_game"));

    public static final SoundEvent YUZU_TITLE_SENREN = SoundEvent.of(Identifier.of(YuZuUI.MOD_ID, "yuzu_title_senren"));

    public static final SoundEvent YUZU_TITLE_BUTTON_REALMS = SoundEvent.of(Identifier.of(YuZuUI.MOD_ID, "yuzu_title_button_realms"));

    public static void init() {
        Registry.register(
                Registries.SOUND_EVENT,
                Identifier.of(YuZuUI.MOD_ID, "yuzu_title_music"),
                YUZU_TITLE_MUSIC
        );
        Registry.register(
                Registries.SOUND_EVENT,
                Identifier.of(YuZuUI.MOD_ID, "yuzu_title_button_on"),
                YUZU_TITLE_BUTTON_ON
        );
        Registry.register(
                Registries.SOUND_EVENT,
                Identifier.of(YuZuUI.MOD_ID, "yuzu_title_button_click"),
                YUZU_TITLE_BUTTON_CLICK
        );
        Registry.register(
                Registries.SOUND_EVENT,
                Identifier.of(YuZuUI.MOD_ID, "yuzu_title_button_new_game"),
                YUZU_TITLE_BUTTON_NEW_GAME
        );
        Registry.register(
                Registries.SOUND_EVENT,
                Identifier.of(YuZuUI.MOD_ID, "yuzu_title_button_select_world"),
                YUZU_TITLE_BUTTON_SELECT_WORLD
        );
        Registry.register(
                Registries.SOUND_EVENT,
                Identifier.of(YuZuUI.MOD_ID, "yuzu_title_button_options"),
                YUZU_TITLE_BUTTON_OPTIONS
        );
        Registry.register(
                Registries.SOUND_EVENT,
                Identifier.of(YuZuUI.MOD_ID, "yuzu_title_button_quit_game"),
                YUZU_TITLE_BUTTON_QUIT_GAME
        );
        Registry.register(
                Registries.SOUND_EVENT,
                Identifier.of(YuZuUI.MOD_ID, "yuzu_title_senren"),
                YUZU_TITLE_SENREN
        );
        Registry.register(
                Registries.SOUND_EVENT,
                Identifier.of(YuZuUI.MOD_ID, "yuzu_title_button_realms"),
                YUZU_TITLE_BUTTON_REALMS
        );
    }
}
