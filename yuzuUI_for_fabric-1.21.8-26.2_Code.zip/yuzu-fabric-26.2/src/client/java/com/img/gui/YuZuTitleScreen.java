package com.img.gui;

import com.img.YuZuUI;
import com.img.function.AnimationFunction;
import com.img.init.InitSounds;
import com.mojang.realmsclient.RealmsMainScreen;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.multiplayer.SafetyScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.worldselection.CreateWorldScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.Music;
import org.jetbrains.annotations.Nullable;

import java.util.concurrent.CompletableFuture;

import static java.lang.Thread.sleep;

/**
 * @author : IMG
 * @create : 2024/10/20
 *
 * 26.2：原版 TitleScreen 的内部结构（initWidgetsNormal / realmsNotificationGui /
 * doBackgroundFade 等）已完全改写，且 GUI 变为两阶段（extract -> render state）。
 * 因此不再 mixin 原版 TitleScreen，而是一个完全自绘的 Screen 子类，
 * 由 {@code GuiMixin} 在 {@code Gui.setScreen} 处替换原版 TitleScreen。
 */
public class YuZuTitleScreen extends Screen {

    private static final Identifier BACKGROUND_TEXTURE = id("textures/gui/background.png");
    private static final Identifier TITLE_YOSHINO = id("textures/gui/title_yoshino.png");
    private static final Identifier TITLE_MURASAME = id("textures/gui/title_murasame.png");
    private static final Identifier TITLE_MAKO = id("textures/gui/title_mako.png");
    private static final Identifier TITLE_LENA = id("textures/gui/title_lena.png");
    private static final Identifier TITLE_LOGO = id("textures/gui/title_logo.png");
    private static final Identifier TITLE_HEAD = id("textures/gui/title_head.png");

    private static final Identifier TITLE_NEW_GAME_BUTTON_NORMAL = id("textures/gui/title_new_game_button_normal.png");
    private static final Identifier TITLE_NEW_GAME_BUTTON_ON = id("textures/gui/title_new_game_button_on.png");

    private static final Identifier TITLE_SELECT_WORLD_BUTTON_NORMAL = id("textures/gui/title_select_world_button_normal.png");
    private static final Identifier TITLE_SELECT_WORLD_BUTTON_ON = id("textures/gui/title_select_world_button_on.png");

    private static final Identifier TITLE_OPTIONS_BUTTON_NORMAL = id("textures/gui/title_options_button_normal.png");
    private static final Identifier TITLE_OPTIONS_BUTTON_ON = id("textures/gui/title_options_button_on.png");

    private static final Identifier TITLE_QUIT_GAME_BUTTON_NORMAL = id("textures/gui/title_quit_game_button_normal.png");
    private static final Identifier TITLE_QUIT_GAME_BUTTON_ON = id("textures/gui/title_quit_game_button_on.png");

    private static final Identifier TITLE_CONTINUE_BUTTON_NORMAL = id("textures/gui/title_continue_button_normal.png");
    private static final Identifier TITLE_CONTINUE_BUTTON_ON = id("textures/gui/title_continue_button_on.png");

    private static final Identifier TITLE_REALMS_BUTTON_NORMAL = id("textures/gui/title_realms_button_normal.png");
    private static final Identifier TITLE_REALMS_BUTTON_ON = id("textures/gui/title_realms_button_on.png");

    /** 标题界面背景音乐（取代原版 Musics.MENU）。 */
    private static final Music MENU_MUSIC = new Music(Holder.direct(InitSounds.YUZU_TITLE_MUSIC), 50, 50, true);

    private static final double a = 0.06;

    private static final VirtualScreen virtualScreen = new VirtualScreen(1920, 1080);

    private static final int y = 346;
    private static final int dy = 120;
    private static final long delay = 1300L;

    private final Layer yoshinoLayer;
    private final Layer murasameLayer;
    private final Layer makoLayer;
    private final Layer lenaLayer;
    private final Layer logoLayer;
    private final Layer headLayer;

    private final TitleButton newGameButton;
    private final TitleButton selectWorldButton;
    private final TitleButton continueButton;
    private final TitleButton realmsButton;
    private final TitleButton optionsButton;
    private final TitleButton quitGameButton;

    public YuZuTitleScreen() {
        super(Component.translatable("narrator.screen.title"));

        this.yoshinoLayer = new Layer(TITLE_YOSHINO, 504, 50, 973, 1058, 1f, 1f, 0, 0, 256, 256, 256, 256, 0f) {{
            setDelay(delay);
            setDuration(590L);

            setYFunction((t, now) -> (25f - 50f) * (float) ((Math.pow(a, t) - 1) / (a - 1)) + 50f);

            setAlphaFunction((t, now) -> (1f - 0f) * (float) ((Math.pow(a, t) - 1) / (a - 1)) + 0f);
        }};

        this.murasameLayer = new Layer(TITLE_MURASAME, 221, 90, 1045, 994, 1f, 1f, 0, 0, 256, 256, 256, 256, 0f) {{
            setDelay(delay + 110L);
            setDuration(710L);

            setXFunction((t, now) -> (173f - 221f) * (float) ((Math.pow(a, t) - 1) / (a - 1)) + 221f);

            setAlphaFunction((t, now) -> (1f - 0f) * (float) ((Math.pow(a, t) - 1) / (a - 1)) + 0f);
        }};

        this.makoLayer = new Layer(TITLE_MAKO, 805, 387, 1118, 694, 1f, 1f, 0, 0, 256, 256, 256, 256, 0f) {{
            setDelay(delay + 280L);
            setDuration(680L);

            setXFunction((t, now) -> (898f - 805f) * (float) ((Math.pow(a, t) - 1) / (a - 1)) + 805f);

            setAlphaFunction((t, now) -> (1f - 0f) * (float) ((Math.pow(a, t) - 1) / (a - 1)) + 0f);
        }};

        this.lenaLayer = new Layer(TITLE_LENA, 1002, 149, 876, 1053, 1f, 1f, 0, 0, 256, 256, 256, 256, 0f) {{
            setDelay(delay + 440L);
            setDuration(680L);

            setXFunction((t, now) -> (float) ((1065f - 1002f) * ((Math.pow(0.05, t) - 1) / (0.05 - 1)) + 1002f));

            setYFunction((t, now) -> (float) ((27f - 149f) * ((Math.pow(0.05, t) - 1) / (0.05 - 1)) + 149f));

            setAlphaFunction((t, now) -> (float) ((1f - 0f) * ((Math.pow(0.05, t) - 1) / (0.05 - 1)) + 0f));
        }};

        this.logoLayer = new Layer(TITLE_LOGO, 17, 57, 442, 188, 1.067f, 1f, 0, 0, 256, 256, 256, 256, 0f) {{
            setDelay(delay + 300L);
            setDuration(570L);

            setXFunction((t, now) -> (31f - 17f) * (float) ((Math.pow(0.1, t) - 1) / (0.1 - 1)) + 17f);

            setYFunction((t, now) -> (60f - 57f) * (float) ((Math.pow(0.1, t) - 1) / (0.1 - 1)) + 57f);

            setAlphaFunction((t, now) -> (1f - 0f) * (float) ((Math.pow(0.1, t) - 1) / (0.1 - 1)) + 0f);

            setScaleFunction((t, now) -> (1f - 1.067f) * (float) ((Math.pow(0.1, t) - 1) / (0.1 - 1)) + 1.067f);
        }};

        this.headLayer = new Layer(TITLE_HEAD, 0, 0, 536, 1080, 1f, 1f, 0, 0, 256, 256, 256, 256, 0f) {{
            setDelay(delay + 1130L);
            setDuration(530L);

            setAlphaFunction((t, now) -> {
                float v = (1f - 0f) * (float) ((Math.pow(0.1, t) - 1) / (0.1 - 1)) + 0f;
                if (v == 1f && now != 1f) {
                    TitleButton.playSound(InitSounds.YUZU_TITLE_SENREN, 1.0f, 10.0f);
                }
                return v;
            });
        }};

        this.newGameButton = new TitleButton(60, y, 207, 54, TITLE_NEW_GAME_BUTTON_NORMAL, TITLE_NEW_GAME_BUTTON_ON, virtualScreen, 0f);
        this.selectWorldButton = new TitleButton(60, y + dy, 206, 55, TITLE_SELECT_WORLD_BUTTON_NORMAL, TITLE_SELECT_WORLD_BUTTON_ON, virtualScreen, 0f);
        this.continueButton = new TitleButton(66, y + dy * 2, 313, 56, TITLE_CONTINUE_BUTTON_NORMAL, TITLE_CONTINUE_BUTTON_ON, virtualScreen, 0f);
        this.realmsButton = new TitleButton(66, y + dy * 3, 164, 54, TITLE_REALMS_BUTTON_NORMAL, TITLE_REALMS_BUTTON_ON, virtualScreen, 0f);
        this.optionsButton = new TitleButton(59, y + dy * 4, 253, 56, TITLE_OPTIONS_BUTTON_NORMAL, TITLE_OPTIONS_BUTTON_ON, virtualScreen, 0f);
        this.quitGameButton = new TitleButton(60, y + dy * 5, 233, 54, TITLE_QUIT_GAME_BUTTON_NORMAL, TITLE_QUIT_GAME_BUTTON_ON, virtualScreen, 0f);

        AnimationFunction<Float> fadeIn = (t, now) -> (1f - 0f) * t + 0f;
        for (TitleButton button : this.buttons()) {
            button.setDelay(delay + 1670L);
            button.setDuration(570L);
            button.setAlphaFunction(fadeIn);
        }
    }

    private static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(YuZuUI.MOD_ID, path);
    }

    private TitleButton[] buttons() {
        return new TitleButton[]{newGameButton, selectWorldButton, continueButton, realmsButton, optionsButton, quitGameButton};
    }

    @Override
    protected void init() {
        this.newGameButton.setOnClick(button ->
                CreateWorldScreen.openFresh(this.minecraft, () -> this.minecraft.setScreenAndShow(new YuZuTitleScreen())));

        this.selectWorldButton.setOnClick(button -> {
            TitleButton.playSound(InitSounds.YUZU_TITLE_BUTTON_SELECT_WORLD, 1.0f, 10.0f);
            this.minecraft.setScreenAndShow(new SelectWorldScreen(this));
        });

        this.continueButton.setOnClick(button -> {
            Screen screen = this.minecraft.options.skipMultiplayerWarning
                    ? new JoinMultiplayerScreen(this)
                    : new SafetyScreen(this);
            this.minecraft.setScreenAndShow(screen);
        });

        this.realmsButton.setOnClick(button -> {
            TitleButton.playSound(InitSounds.YUZU_TITLE_BUTTON_REALMS, 1.0f, 10.0f);
            this.minecraft.setScreenAndShow(new RealmsMainScreen(this));
        });

        this.optionsButton.setOnClick(button -> {
            TitleButton.playSound(InitSounds.YUZU_TITLE_BUTTON_OPTIONS, 1.0f, 10.0f);
            this.minecraft.setScreenAndShow(new OptionsScreen(this, this.minecraft.options, false));
        });

        this.quitGameButton.setOnClick(button -> {
            TitleButton.playSound(InitSounds.YUZU_TITLE_BUTTON_QUIT_GAME, 1.0f, 10.0f);
            CompletableFuture.completedFuture(null).whenComplete((unused, e) -> {
                try {
                    sleep(1500);
                } catch (InterruptedException ex) {
                    throw new RuntimeException(ex);
                }
                this.minecraft.stop();
            });
        });
    }

    @Override
    public void tick() {
        this.yoshinoLayer.tick();
        this.murasameLayer.tick();
        this.makoLayer.tick();
        this.lenaLayer.tick();
        this.headLayer.tick();
        this.logoLayer.tick();
        for (TitleButton button : this.buttons()) {
            button.tick();
        }
    }

    @Nullable
    @Override
    public Music getBackgroundMusic() {
        return MENU_MUSIC;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        // 完全自绘，不绘制原版全景背景 / 模糊背景。
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        // 背景图片保持比例
        int screenWidth = this.width;
        int screenHeight = this.height;
        // 背景适应后的数据
        int currentWidth;
        int currentHeight;
        if (screenWidth * 9 > screenHeight * 16) {
            currentWidth = screenHeight * 16 / 9;
            currentHeight = screenHeight;
        } else {
            currentWidth = screenWidth;
            currentHeight = screenWidth * 9 / 16;
        }
        int currentX = (screenWidth - currentWidth) / 2;
        int currentY = (screenHeight - currentHeight) / 2;

        virtualScreen.setPracticalWidth(currentWidth);
        virtualScreen.setPracticalHeight(currentHeight);
        virtualScreen.setX(currentX);
        virtualScreen.setY(currentY);

        graphics.fill(0, 0, screenWidth, screenHeight, 0xFF000000);
        graphics.enableScissor(currentX, currentY, currentX + currentWidth, currentY + currentHeight);

        graphics.blit(
                RenderPipelines.GUI_TEXTURED,
                BACKGROUND_TEXTURE,
                currentX,
                currentY,
                0.0F,
                0.0F,
                currentWidth,
                currentHeight,
                16,
                16,
                16,
                16,
                0xFFFFFFFF
        );

        this.lenaLayer.render(currentX, currentY, graphics, virtualScreen);
        this.makoLayer.render(currentX, currentY, graphics, virtualScreen);
        this.murasameLayer.render(currentX, currentY, graphics, virtualScreen);
        this.yoshinoLayer.render(currentX, currentY, graphics, virtualScreen);

        int headColor = Layer.toColor(this.headLayer.getAlpha());
        // 左侧立绘白底 + 向右的渐隐
        graphics.fill(
                currentX,
                currentY,
                currentX + (int) virtualScreen.toPracticalX(296),
                currentY + (int) virtualScreen.toPracticalY(1080),
                headColor
        );
        graphics.fillGradient(
                currentX + (int) virtualScreen.toPracticalX(296),
                currentY,
                currentX + (int) virtualScreen.toPracticalX(600),
                currentY + (int) virtualScreen.toPracticalY(1080),
                headColor,
                0x00FFFFFF
        );
        graphics.blit(
                RenderPipelines.GUI_TEXTURED,
                TITLE_HEAD,
                currentX,
                currentY + (int) virtualScreen.toPracticalY(334),
                0.0F,
                0.0F,
                (int) virtualScreen.toPracticalX(12),
                (int) virtualScreen.toPracticalY(687),
                256,
                256,
                256,
                256,
                headColor
        );

        for (TitleButton button : this.buttons()) {
            button.render(graphics, mouseX, mouseY);
        }

        this.logoLayer.render(currentX, currentY, graphics, virtualScreen);

        graphics.disableScissor();
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() == 0) {
            for (TitleButton button : this.buttons()) {
                if (button.mouseClicked(event.x(), event.y())) {
                    return true;
                }
            }
        }
        return super.mouseClicked(event, doubleClick);
    }
}
