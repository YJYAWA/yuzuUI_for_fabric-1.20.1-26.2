package com.img.mixin.client;

import com.img.gui.YuZuTitleScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * @author : IMG
 * @create : 2024/10/19
 *
 * 26.2 中所有界面切换（包括启动时的初始界面）都经过 Gui.setScreen(Screen)，
 * 在这里把原版 TitleScreen 换成自绘的 YuZuTitleScreen。
 *
 * <p>注意：{@code setScreen} 内部对 {@code screen == null && minecraft.level == null} 的情况
 * 会把局部变量赋值为 {@code new TitleScreen()}，这个赋值发生在方法体内，
 * {@code @ModifyVariable(argsOnly = true)} 无法拦截，因此必须在 HEAD 处 @Inject 并 cancel。
 */
@Mixin(Gui.class)
public class GuiMixin {

    @Shadow
    @Final
    private Minecraft minecraft;

    @Shadow
    private boolean clientLevelTeardownInProgress;

    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void yuzu$replaceTitleScreen(Screen screen, CallbackInfo ci) {
        Gui gui = (Gui) (Object) this;

        // 递归调用是安全的：内层传入的是 YuZuTitleScreen，既不为 null 也不是 TitleScreen，
        // 会直接 return，不会再触发替换。
        if (screen != null) {
            if (screen.getClass() == TitleScreen.class) {
                gui.setScreen(new YuZuTitleScreen());
                ci.cancel();
            }
            return;
        }

        // 与原版判断保持一致：teardown 进行中原版会抛 IllegalStateException，不要拦截。
        if (!this.clientLevelTeardownInProgress && this.minecraft.level == null) {
            gui.setScreen(new YuZuTitleScreen());
            ci.cancel();
        }
    }
}
