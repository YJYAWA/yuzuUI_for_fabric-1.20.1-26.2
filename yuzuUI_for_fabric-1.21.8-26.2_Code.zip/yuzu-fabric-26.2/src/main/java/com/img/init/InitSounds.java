package com.img.init;

import com.img.YuZuUI;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

/**
 * @author : IMG
 * @create : 2024/10/19
 *
 * 26.2：SoundEvent.of(...) 与 Registries/Registry(registry.Registry) 均已移除，
 * 改为 SoundEvent.createVariableRangeEvent(...) + BuiltInRegistries.SOUND_EVENT。
 */
public class InitSounds {

    public static final SoundEvent YUZU_TITLE_MUSIC = register("yuzu_title_music");

    public static final SoundEvent YUZU_TITLE_BUTTON_ON = register("yuzu_title_button_on");

    public static final SoundEvent YUZU_TITLE_BUTTON_CLICK = register("yuzu_title_button_click");

    public static final SoundEvent YUZU_TITLE_BUTTON_NEW_GAME = register("yuzu_title_button_new_game");

    public static final SoundEvent YUZU_TITLE_BUTTON_SELECT_WORLD = register("yuzu_title_button_select_world");

    public static final SoundEvent YUZU_TITLE_BUTTON_OPTIONS = register("yuzu_title_button_options");

    public static final SoundEvent YUZU_TITLE_BUTTON_QUIT_GAME = register("yuzu_title_button_quit_game");

    public static final SoundEvent YUZU_TITLE_SENREN = register("yuzu_title_senren");

    public static final SoundEvent YUZU_TITLE_BUTTON_REALMS = register("yuzu_title_button_realms");

    private static SoundEvent register(String path) {
        Identifier id = Identifier.fromNamespaceAndPath(YuZuUI.MOD_ID, path);
        return Registry.register(BuiltInRegistries.SOUND_EVENT, id, SoundEvent.createVariableRangeEvent(id));
    }

    public static void init() {
        // 所有音效都在静态字段初始化时完成注册，此处仅用于触发类加载。
        YuZuUI.LOGGER.info("[YuZuUI] registered 9 sound events");
    }
}
